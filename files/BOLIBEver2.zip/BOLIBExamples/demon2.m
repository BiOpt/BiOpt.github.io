clc; close all; 
ExName = 'ShimizuEtal1997a';   % Change the example you want to test here
                               % ExName can be the name of an example
                               % Or ExName can be can any number between [1,173] such as
                               % ExName = 108;
dim  = [1 1 1 1]';             % (n_x,n_y,n_G,n_g)
                               % dimension must match the example
x    = ones(dim(1),1); 
y    = ones(dim(2),1);  

func = str2func(ExName); 
F    = func(x,y,'F',[]) 
Fx   = func(x,y,'F','x') 
Gy   = func(x,y,'G','y') 
fxy  = func(x,y,'f','xy') 
gyy  = func(x,y,'g','yy')