function Out = SNQVI(func,dim,pars)
% The original code aims to solve optimization problems with quasi-variational 
% inequalities constraints in the form:
%
%            min_{x,y}  F(x,y)  s.t. G(x,y) <= 0, 
%                                    y \in { <f0(x,y),z-y>: g(x,y,z)<=0 } 
%
% where x \in R^{n_x}, y \in R^{n_y}, G(x,y)\in R^{n_G}, g(x,y)\in R^{n_g},   
% f0(x,y)\in R^{n_y} with n_x>0, n_y>0, n_G>=0 and n_g>=0.
%
% This is the version of solving  bilevel optimization in the form
%
%           min_{x,y}  F(x,y)  s.t. G(x,y)<=0, 
%                                   y \in argmin_y { f(x,y): g(x,y)<=0 }
%
% where x \in R^{n_x}, y \in R^{n_y}, G(x,y)\in R^{n_G}, g(x,y)\in R^{n_g}  
% with n_x>0, n_y>0, n_G>=0 and n_g>=0
%
% Input:
%     dim : A row (or column) vector with FOUR elements, i.e., dim=[n_x n_y n_G n_g] 
%     func: A function handle (or a string) must contain Four functions [F G f g], (required)
%           preferably including 1st and 2nd order derivatives of F,G,f and g,     (optional)
%                                3rd order derivatives of f                        (optional)
%     pars: Starting point, parameters and other information. 
%           All are optional except for pars.data
%           pars.xy:     The starting point for x and y, i.e.,pars.xy=[x0;y0]                     
%                        It is a COLUMN vector whose dimension is (n_x+n_y)
%                        Default one pars.xy=zeros(n_x+n_y,1)
%           pars.lam:    A positive penalty parameter, default one pars.lam=1 
%                        NOTE: It is an important parameter 
%                        Different choices may produce  different results 
%           pars.varlam: allow pars.lam to be varied if pars.varlam=1 (default)
%                        fix pars.lam  if pars.varlam=0
%           pars.check:  Check the completeness of all 1st,2nd order derivatives
%                        of F, G, f and g and 3rd order derivatives of f 
%                        =1 does check (default), =0 does not check
%           pars.iterin: Show results for each iteration if pars.iteron=1 (default)
%                        Don't show results for each iteration if pars.iteron=0  
%           pars.maxit:  Maximum iteration number, default one pars.maxit=2000
%           pars.tol:    Tolerance for the stopping criteria, default one pars.tol=1e-8
%           pars.draw:   A  graph will be drawn if pars.draw=1  
%                        No graph will be drawn if pars.draw=0 (default)
%           pars.data:   This extra data is relied on the example that will be solved  
%                        If one example does not need extra data, then no need pars.data  
%                        Otherwise, input the data. The latter case means nargin(func)=5  
%           pars.keep:   This is only valid when pars.check=1
%                        =1, keep all calculated derivatives in DerivativesFile folder 
%                        =0, delete all calculated derivatives in DerivativesFile folder (default) 
%
% Output:
%     Out.x:             solution x
%     Out.y:             solution y
%     Out.F:             Objective function value
%     Out.time:          CPU time
%     Out.iter:          Number of iterations
%     Out.error:         Error 
%
%
%%%%%%%    Send your comments and suggestions to                     %%%%%%
%%%%%%%    shenglong.zhou@soton.ac.uk                                %%%%%%
 
%%%%%%%    Warning: Accuracy may not be guaranteed!!!!!              %%%%%%

%%%%%%%    This version: July 30, 2019                               %%%%%%

%%%%%%%    written by Shenglong Zhou                                 %%%%%%

clock  = tic;
warning off; 

if nargin<2 
   error('No enough inputs\n'); 
end   
 
if length(dim)~=4
   fprintf('Dimensions are incorrect, please input again\n'); return;
end

if nargin==2 
   pars.lam = 1; % an important parameter
end

if isfield(pars,'lam');    pars.lam = pars.lam;  else; pars.lam = 1;  end
if isfield(pars,'iteron'); iteron = pars.iteron; else; iteron = 1;    end
if isfield(pars,'draw');   draw   = pars.draw;   else; draw   = 0;    end
if isfield(pars,'keep');   keep   = pars.keep;   else; keep   = 0;    end
if isfield(pars,'maxit');  maxit  = pars.maxit;  else; maxit  = 2000; end
if isfield(pars,'tol');    errtol = pars.tol;    else; errtol = 1e-8; end
if isfield(pars,'check');  check  = pars.check;  else; check  = 1;    end
if isfield(pars,'varlam'); varlam = pars.varlam; else; varlam = 1;    end 

if  isa(func,'function_handle')
    strfunc   = func2str(func); 
    narginf   = nargin(func); 
else
    strfunc   = func;
    func      = str2func(func);
    narginf   = nargin(func);     
end 

if  narginf==5 
    if ~isfield(pars,'data');  error('Input data is missing...');  end
end

if  check    
    copyfunc     = CheckOutput(strfunc); 
    if exist('DerivativesFile')
       addpath('DerivativesFile') ;
    end    
    if narginf  ~= nargin(copyfunc)
        if ~isfield(pars,'data');  error('Input data is missing...');  end
        narginf  = nargin(copyfunc);
    end
    if  narginf  < 5 
        mark     = CompleteDerivatives(copyfunc,dim,'f');
    else                  
        mark     = CompleteDerivatives(copyfunc,dim,'f',pars.data);  
        copyfunc = @(x,y,keyf,keyxy)copyfunc(x,y,keyf,keyxy,pars.data);
    end    
    fun = @(x,y,keyf,keyxy)GetDerivativesQVIB(x,y,keyf,keyxy,copyfunc,mark); 
else    
    if  narginf  < 5
        copyfunc = func;           
    else
        copyfunc = @(x,y,keyf,keyxy)func(x,y,keyf,keyxy,pars.data);
    end  
    mark = ones(4,9); 
    fun  = @(x,y,keyf,keyxy)GetDerivativesQVIB(x,y,keyf,keyxy,copyfunc,mark); 
end

 
sigma  = 1e-6;
beta   = 1e-8; 
t      = 1.05;
NoArmi = 6;
J      = NoArmi;
alpha0 = 2;


num    = getnumber(dim);
if isfield(pars, 'xy')
x      = pars.xy(1:num(1),:);
y      = pars.xy(num(1)+1:num(2),:);
else       
x      = zeros(dim(1),1);
y      = zeros(dim(2),1);
end
             
X         = getstartpoint(x,y,fun,num,dim);
pars.num  = num;
pars.dim  = dim;
P         = Phi(fun, X, pars ); 
Error     = FNorm(P);  
pars.lam0 = pars.lam ;
 
Err       = Inf*ones(maxit,1);
XX        = zeros(maxit,1);
f0        = abs(fun(x,y,'F',[])); 
nX        = length(P);
flag1     = 0; 
flag2     = 0;
flag3     = 1;
fluct     = zeros(maxit,1);
Obj       = zeros(maxit,2);

fprintf('\n\nStart to run SNQIV solver...');
fprintf('\n--------------------------------------------\n');
if  iteron 
    fprintf('\nIter    Upper-Obj    Lower-Obj      CPU-Time');   
    fprintf('\n--------------------------------------------\n');    
end

for iter    =  1:maxit 
         
    W       =  Jacobian_Phi(fun, X, pars);  
    WP      =  (P'*W)'; 
    if nX   >  1e4
    d       = -pcg(W,P,1e-6,100);
    else
    d       = -W\P;      
    end
    Error0  =  Error;
    gap     =  0;
    re      =  Inf*ones(1,4);
    for i   =  1:4     
        if  max(isnan(d))==1 || FNorm(d) > max(1e10,f0) || flag1
            if     i<=2 ; WW = W'*W; WWI  = WW;
                          WWI(1:1+nX:end) = WWI(1:1+nX:end)+1e-6*min(1,Error);
                          if nX>=1000; [d,~] = pcg(WWI,-WP,1e-6,100 );   
                          else;       d  = -WWI\WP;
                          end
            elseif i==3 ; [d,~] = pcg(WW,-WP,1e-6,100 );
            end
        end 
        
        Normd        =  FNorm(d);
        WPd          =  sum(sum(WP.*d)); %     
        if flag1 && i == 4           
           WPdg      =  sum(sum(WP.*WP));  
           if (WPd    > -beta*Normd^t && WPd>-WPdg)  || isnan(WPd)      
              WPd    = -WPdg;  
              d      = -WP;           
           end          
        end
 
        if iter>5
            rate         = sqrt(Normd)/(NormX+1);    
            if  rate     > 1e2 
                alpha0   = 1/sqrt(rate);   
                J        = NoArmi; 
                flag2     = 0;
            elseif rate  < 1e-6 && rate > 1e-10 && Error > 1e-4 
                alpha0   = 1/rate;      
                J        = ceil(log2(alpha0))+ NoArmi;   
                flag2     = 0;
            end
   
            if  rate >= 1e-6 && rate <=1e2 && (mod(iter,10)==0 || ~flag2)
                if Error < errtol/10
                    alpha0   = 1;       
                    J        = NoArmi; 
                elseif iter  > 10 && sum(fluct(iter-10:iter-1))>=3 
                    alpha0   = 2;         
                    J        = NoArmi+4; 
                else
                    alpha0   = 2;       
                    J        = NoArmi;                
                end
                flag2         = 1; 
            end
        end       
 
        alpha        = alpha0;   
        j            = 1;         
        while j     <= J
            Xnew     = X + alpha*d;   
            P        = Phi(fun,Xnew,pars );  
            Error    = FNorm(P);   
            if Error < Error0+sigma*alpha*WPd; break;  end    
            alpha    = alpha*0.5;
            j        = j+1;
            if j >J && Error/Error0>1e8
            J        = NoArmi+5; 
            end
        end 
 
        if (j>J && Error/Error0>1e4) || Normd<1e-8
            Xnew1  = X - alpha*WP;      
            P1     = Phi(fun,Xnew,pars );   
            Error1 = FNorm(P);     
            if Error1 > Error 
            Xnew   = Xnew1;  
            P      = P1;   
            Error  = Error1 ;  
            end
        end        
        
        re(i)     = Error;              
        if i>1   && re(i) < re(i-1)
           Err0   = re(i);    
           alp0   = alpha; 
           P0     = P; 
           Xn0    = Xnew;  
           gap    = gap+1; 
        end
      
        if Error  < 1e6*max(1,Error)*Error0
            flag1  = 0; break;  
        else              
            flag1  = 1;            
        end    
    end
 
    if gap
       Error  = Err0;  
       alpha  = alp0;
       P      = P0;
       Xnew   = Xn0;               
    end
 
    if Error>Error0; fluct(iter)=1; end
    
    NormX      = sqrt(FNorm(Xnew)); 
    Err(iter)  = sqrt(Error);
    if  iter   > 100 && iter  < maxit-100  && flag3==1 
        Ind    = iter-99:iter;
        sq     = Err(Ind); 
        stdErr = std(sq);   
        msq    = max(sq); 
        cond  = (mod(iter,500)==0 && sum(fluct(Ind))>20);  
        cond2  = (rate<1e-6);  
        cond3  = (stdErr<1e-3*msq);   
        cond4  = (sq(end)> 100*errtol);  
    if  isnan(NormX) || ( cond4 && (cond || cond2 || cond3) )                    
        x      = X(1:num(1),:);
        y      = X(num(2)+1:num(3),:);  
        if dim(3)~=0 && dim(4)==0
           G0  = fun(x,y,'G',[]);
           if  max(G0>1e-3)==0 
           y   = X(num(1)+1:num(2),:);  
           end            
        end
        Xnew     = getstartpoint(x,y,fun,num,dim);
        pars.lam = pars.lam0/log(iter);         
        P        = Phi(fun,Xnew,pars);   
        Error    = FNorm(P);       
        flag3    = 0;  
        iter0    = iter;
    else
        pars.lam = pars.lam0; 
        flag3    = 1; 
    end
    end

    if  flag3==0 &&  iter == iter0+50
        flag3=1;
    end
        
    XX         = [XX(2:3) ;sqrt(FNorm(Xnew-X))] ; 
    X          = real(Xnew); 
    P          = real(P);
    NX         = sqrt(FNorm(Xnew));
    Err(iter)  = sqrt(Error)/(1+(NX>1e2)*NX);
    vx         = X(1:num(1),:);
    vy         = X(num(1)+1:num(2),:);
    F          = fun(vx,vy,'F',[]);
    f          = func(vx,vy,'f',[]);
    Obj(iter,:)= [F f]; 
    if  iteron 
        fprintf('%4d     %8.3f     %8.3f     %6.2fsec\n',iter, F, f, toc(clock));
    end

    if  pars.lam == pars.lam0 
        if Err(iter)<errtol
           break;
        elseif Err(iter)<1e-2           
           if  iter>100 && stdErr<1e-6
               fprintf('\n--------------------------------------------');
               fprintf('\nError didn''t change for last 100 iterations!')
               break;   
           end          
           if  iter>50
               stdObj=std(Obj(iter-50:iter,1)/abs(Obj(iter,1)));
               stdobj=std(Obj(iter-50:iter,2)/abs(Obj(iter,2)));
               if max(stdObj,stdobj)<1e-6
               fprintf('\n--------------------------------------------');
               fprintf('\nObjectives didn''t change for last 50 iterations!')
               break; 
               end
           end     
        end
    elseif pars.lam ~= pars.lam0 
        if Err(iter)<errtol
           if  varlam 
               break;
           else 
               pars.lam = pars.lam0;
               flag3    = 0;
           end
        end
    end
    
    
end
 
% Results output 
Out.x     = X(1:num(1),:);
Out.y     = X(num(1)+1:num(2),:);
Out.z     = X(num(2)+1:num(3),:);
Out.u     = X(num(3)+1:num(4),:);
Out.v     = X(num(4)+1:num(5),:);
Out.w     = X(num(5)+1:num(6),:);

if norm(Out.z)>1e-2
Out.yz    = norm(Out.y-Out.z)/norm(Out.z);
else
Out.yz    = norm(Out.y-Out.z);
end

if norm(Out.w)>1e-2 
Out.vw    = norm(Out.v-Out.w)/ norm(Out.w);
else
Out.vw    = norm(Out.v-Out.w);    
end

Out.F     = fun(Out.x,Out.y,'F',[]); 
Fxz       = fun(Out.x,Out.z,'F',[]);  
Out.f     = func(Out.x,Out.y,'f',[]);
cond1     = 1;

if dim(3) > 0  
cond1      = max(fun(Out.x,Out.z,'G',[])>5e-3)==0; 
end

fy        = fun(Out.x,Out.y,'f',[]);  
cond2     = ((Out.y-Out.z)'*fy>=1e-2);  

if Err(iter) < errtol && cond2
    if Out.F >= Fxz && cond1 
       Out.y     = Out.z;
       Out.F     = Fxz; 
       Out.yz    = 0;
    elseif Out.F < Fxz && cond1
       featic= tic;
       if dim(2) > 50  
            T1 = []; T2 = [];
            if dim(3)>0; T1=find(abs(fun(Out.x,Out.y,'G',[]))<5e-3); end
            if dim(4)>0; T2=find(abs(fun(Out.x,Out.y,'g',[]))<5e-3); end
            Gxy = fun(Out.x,Out.y,'G','y'); 
            gxy = fun(Out.x,Out.y,'g','y');        
            if ~isempty([T1;T2]); fz.fopt = -[Gxy(T1,:)' gxy(T2,:)']\fy;
            else                ; fz.fopt = -(norm(fy)>5e-3);
            end
       else
            objf  = @(vx,vy)func(vx,vy,'f',[]);
            cong  = @(vx,vy)fun(vx,vy,'g',[]);
            fz    = SolOVF(dim(2),objf,cong,Out.x);
       end
       fprintf('\n---------------------------------------------------');  
       fprintf('\nLower-level problem feasiblity check used %4.3f sec',toc(featic)); 
       if Out.f-fz.fopt>0.05*abs(Out.f) 
       Out.y     = Out.z;
       Out.F     = Fxz; 
       Out.yz    = 0;
       end        
    end
    if Out.yz == 0
       fprintf('\nLower level problem variable now is repalced!\n');       
       fprintf('\nNew upper and lower level obj are as follows:'); 
    end
    fprintf('\n---------------------------------------------------\n');
else
    fprintf('\n--------------------------------------------\n');   
end


if iter>2
Out.EOC   = max(log(XX(3))/log(XX(2)),log(XX(2))/log(XX(1)));
elseif iter==2 
Out.EOC   = log(XX(3))/log(XX(2));
else
Out.EOC   = Inf;
end

Out.iter  = iter;
Out.time  = toc(clock);
Out.error = Err(iter);
Out.alpha = alpha; 

if  max(dim(1),dim(2))<=10 
    fprintf('\nx      = ');
    for i=1:dim(1);      fprintf('%10.4f ', Out.x(i) ); end
    fprintf('\ny      = ');
    for i= 1:dim(2);  fprintf('%10.4f ', Out.y(i) ); end
end
    
fprintf('\nF(x,y) = %10.4f \n',  Out.F );
fprintf('f(x,y) = %10.4f \n',  Out.f);
fprintf('Error  = %10.2e  \n', Out.error);
fprintf('Iter   = %10d  \n', iter);
fprintf('Time   = %10.4f sec\n\n', Out.time);

infG =0; 
if dim(3)>0 
G0   = fun(Out.x,Out.y,'G',[]);
infG = nnz(find(G0(G0>5e-3)));
end
infg =0;
if dim(4)>0
g0   = fun(Out.x,Out.y,'g',[]); 
infg = nnz(find(g0(g0>5e-3)));
end

if infG || infg 
    fprintf('\n-----------------------\n');
    fprintf('Solution is infeasible!'); 
    fprintf('\n-----------------------\n');
end


Out.feasible=~(infG || infg );

 if draw
    LastIt=20;
    figure
    if iter<=LastIt 
        plot(1:iter,Err(1:iter,1)); hold on
        xlabel('Iter'); grid on;
    else
        LT=iter-LastIt+1:iter;
        plot(LT,Err(LT,1)); hold on
        xlabel('Last 20 iterations'); grid on;
    end
    
    ylabel('Error')
 end 
 
 if ~keep && exist('DerivativesFile','dir')
    mkdir('DerivativesFile')
    rmdir('DerivativesFile','s')
 end
end

% ========================================================================
function num=getnumber(dim)
dim0   = [dim(1) dim(2) dim(2) dim(3) dim(4) dim(4)];
num    = [dim0(1) zeros(1,5)];
for i=2:6
num(i) = num(i-1)+dim0(i);
end
end

% ========================================================================
function X=getstartpoint(x,y,fun,num,dim)
nX                   = num(end);
X                    = zeros(nX,1);
X(1:num(1),:)        = x;
X(num(1)+1:num(3),:) = [y;y];

if dim(3)>0
fGxy                 = fun(x,y,'G',[]);
X(num(3)+1:num(4),:) = abs(fGxy); 
end

if dim(4)>0
fgxy                 = fun(x,y,'g',[]);
X(num(4)+1:num(5),:) = abs(fgxy);
X(num(5)+1:num(6),:) = abs(fgxy);       
end
end

% ========================================================================
function FNorm_x = FNorm( x )
 FNorm_x = sum(sum(x.*x));
end

% ========================================================================
function  phi = Phi(fun,X,pars )

num   = pars.num;
dim   = pars.dim;
lam   = pars.lam;
x     = X(1: num(1),:);
y     = X(num(1)+1:num(2),:);
z     = X(num(2)+1:num(3),:);
u     = X(num(3)+1:num(4),:);
v     = X(num(4)+1:num(5),:);
w     = X(num(5)+1:num(6),:);
 

if dim(3)>0 
Gxyx  = fun(x,y,'G','x');
Gxyy  = fun(x,y,'G','y');
else
Gxyx  = 0;
Gxyy  = 0; 
u     = 0;
end

if dim(4)>0 
gxyx  = fun(x,y,'g','x');
gxyy  = fun(x,y,'g','y');
gxzx  = fun(x,z,'g','x');
gxzy  = fun(x,z,'g','y');
else
gxyx  = 0;
gxyy  = 0;
gxzx  = 0;
gxzy  = 0;
w     = 0;
v     = 0;
end
 
JLx  = fun(x,y,'F','x') + Gxyx'*u   + gxyx'*v   + ... 
       lam*(fun(x,y,'f','x')'*(y-z) - gxzx'*w);
JLy  = fun(x,y,'F','y') +  Gxyy'*u  + gxyy'*v   + ...
       lam*(fun(x,y,'f',[]) + fun(x,y,'f','y')'*(y-z));
                   
Jlz  = -lam*( fun(x,y,'f',[]) +  gxzy'*w);

if dim(3)>0 
Gu   = FB_fun(u,-fun(x,y,'G',[]));
end

if dim(4)>0 
gv  = FB_fun(v,-fun(x,y,'g',[]));
gw  = FB_fun(w,-fun(x,z,'g',[]));
end

if     dim(3)>0 && dim(4)>0
       phi  = [JLx; JLy; Jlz; Gu; gv; gw];
elseif dim(3)==0 && dim(4)>0
       phi  = [JLx; JLy; Jlz; gv; gw];  
elseif dim(3)>0 && dim(4)==0
       phi  = [JLx; JLy; Jlz; Gu];
else
       phi  = [JLx; JLy; Jlz];
end
phi  = real(phi);
end

% ========================================================================
function JPhi = Jacobian_Phi(fun,X,pars )

num   = pars.num;
dim   = pars.dim;
lam   = pars.lam;
x     = X(1: num(1),:);
y     = X(num(1)+1:num(2),:);
z     = X(num(2)+1:num(3),:);
u     = X(num(3)+1:num(4),:);
v     = X(num(4)+1:num(5),:);
w     = X(num(5)+1:num(6),:);


JLxx = fun(x,y,'F','xx')+ JuTf(u,fun(x,y,'G','xx')) + JuTf(v,fun(x,y,'g','xx'))+ ...
       lam*( JuTf(y-z,fun(x,y,'f','xx')) - JuTf(w,fun(x,z,'g','xx')) );
JLxy = fun(x,y,'F','xy')+ JuTf(u,fun(x,y,'G','xy')) + JuTf(v,fun(x,y,'g','xy'))+ ...
       lam*( JuTf(y-z,fun(x,y,'f','xy')) + fun(x,y,'f','x') );        
JLxz = -lam*( fun(x,y,'f','x') + JuTf(w,fun(x,z,'g','xy')) );
JLxu = fun(x,y,'G','x');
JLxv = fun(x,y,'g','x');
JLxw = -lam*fun(x,z,'g','x');


JLyy = fun(x,y,'F','yy') + JuTf(u,fun(x,y,'G','yy')) + JuTf(v,fun(x,y,'g','yy'))+ ...
       lam*( 2*fun(x,y,'f','y') + JuTf(y-z, fun(x,y,'f','yy')) ) ;
JLyz = -lam* fun(x,y,'f','y') ;
JLyu = fun(x,y,'G','y'); 
JLyv = fun(x,y,'g','y'); 
JLyw = zeros(dim(4),dim(2));

 
JLzz = - lam*JuTf(w,fun(x,z,'g','yy'));
if JLzz==0
   JLzz =zeros(dim(2),dim(2)); 
end
JLzu = zeros(dim(3),dim(2));
JLzv = zeros(dim(4),dim(2));
JLzw = -lam*fun(x,z,'g','y'); 

if dim(3)>0  
[JGuu,JGux,JGuy]=Diff_ugxy(u,fun(x,y,'G',[]),JLxu,JLyu);
JGuv = zeros(dim(4),dim(3));
JGuw = zeros(dim(4),dim(3));
end

if dim(4)>0   
[Jgvv,Jgvx,Jgvy] = Diff_ugxy(v,fun(x,y,'g',[]),JLxv,JLyv);
[Jgww,Jgwx,Jgwz] = Diff_ugxy(w,fun(x,z,'g',[]),-JLxw/lam,-JLzw/lam);
Jgvw = zeros(dim(4),dim(4));
end

 
if dim(3)>0 && dim(4)>0     
JPhi=[JLxx  JLxy'  JLxz'  JLxu'  JLxv'  JLxw'; 
      JLxy  JLyy   JLyz'  JLyu'  JLyv'  JLyw'; 
      JLxz  JLyz   JLzz   JLzu'  JLzv'  JLzw'; 
      JGux  JGuy   JLzu   JGuu   JGuv'  JGuw'; 
      Jgvx  Jgvy   JLzv   JGuv   Jgvv   Jgvw'; 
      Jgwx  JLyw   Jgwz   JGuw   Jgvw   Jgww];
elseif dim(3)==0 && dim(4)>0 
JPhi=[JLxx  JLxy'  JLxz'  JLxv'  JLxw'; 
      JLxy  JLyy   JLyz'  JLyv'  JLyw'; 
      JLxz  JLyz   JLzz   JLzv'  JLzw'; 
      Jgvx  Jgvy   JLzv   Jgvv   Jgvw'; 
      Jgwx  JLyw   Jgwz   Jgvw   Jgww];
elseif dim(3)>0 && dim(4)==0    
JPhi=[JLxx  JLxy'  JLxz'  JLxu'; 
      JLxy  JLyy   JLyz'  JLyu'; 
      JLxz  JLyz   JLzz   JLzu'; 
      JGux  JGuy   JLzu   JGuu];
else
JPhi=[JLxx  JLxy'  JLxz'; 
      JLxy  JLyy   JLyz'; 
      JLxz  JLyz   JLzz];
end

JPhi= real(JPhi);

end

% ========================================================================
function Juf = JuTf(u,Jf) 
    if ~isempty(Jf)
        nG    = size(u,1);
        nx    = size(Jf,2);
        ny    = size(Jf,1)/nG;
        Juf   = zeros(ny,nx);
        for i = 1:nG
        Juf   = Juf+ u(i)*Jf( (1+(i-1)*ny):(i*ny),: );
        end
        Juf   = real(Juf);
    else
        Juf   = 0;
    end
end

% ========================================================================
function FB=FB_fun(a,b)
%ab = a+b;
FB = sqrt(a.*a+b.*b)-a-b ;
% T  = find(ab>0);
% FB(T)=-2*a(T).*b(T)./(FB(T)+2*ab(T));
end

% ========================================================================
function [Jguu,Jgux,Jguy]=Diff_ugxy(u,gxy,Jgx,Jgy)
aug  = u.^2+gxy.^2;
T    = find(aug<1e-4);
Tc   = find(aug>=1e-4);
jguu = u;
jgxy = u;
s    = sum(Jgx,2)+sum(Jgy,2);

if ~isempty(T)
    ss     = sqrt(1+s(T).^2);
    jguu(T)= 1./ss-1;
    jgxy(T)= s(T)./ss+1;
end

if ~isempty(Tc)
    sug     = sqrt(aug(Tc));
    jguu(Tc)= u(Tc)./sug-1;
    jgxy(Tc)= gxy(Tc)./sug+1;
end

Jguu = diag(jguu);
Jgux = diag(jgxy)*Jgx;
Jguy = diag(jgxy)*Jgy;

end

function w = GetDerivativesQVIB(x,y,keyf,keyxy,fun,mark)

keyf0  = {'F', 'G', 'f', 'g'};
for i  = 1:4  
    if isequal(keyf0{i},keyf); break; end  
end

keyf0     = {'F1', 'G1', 'f', 'g'};
keyxy0    = {'x', 'y', 'xx', 'xy', 'yy', 'yxx', 'yxy', 'yyy'};
mark_new  = mark(i,:);
keyxy_new = keyxy;
if i==3
   if isequal(keyxy, 'x'); keyxy_new = 'xy';
   else;                   keyxy_new = strcat('y',keyxy);
   end
   keyxy0 = {'y', 'xy', 'yy', 'yxx', 'yxy', 'yyy'};
   mark_new  = mark(3,[2 4 5 6 7 8]); 
end        

for j  = 1:length(keyxy0)
    if  isequal(keyxy0{j},keyxy_new); break; end
end

if  i~=3 && isempty(keyxy)
    w = fun(x,y,keyf,[]);
else
    if  mark_new(j)==1
    	w = fun(x,y,keyf,keyxy_new);
    elseif mark_new(j)==2
        w = [];
    else
        if length(x)<=20 && length(y)<=20
        filename  = str2func(strcat(keyf0{i}, keyxy_new)); 
        w         = filename(x,y);
        else
        varx      = sym('x',[length(x),1]);
        vary      = sym('y',[length(y),1]);
        filename  = strcat(strcat(keyf0{i}, keyxy_new),'.mat'); 
        load(filename);
        fw        = @(vx,vy)double(subs(symFfxy,[varx;vary],[vx;vy])); 
        w         = fw(x,y);
        end
    end          
end

end
