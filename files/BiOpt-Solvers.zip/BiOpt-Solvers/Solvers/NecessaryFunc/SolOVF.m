function  out = SolOVF(ny,objf,cong,varx,yo)
% This code aims solve a value function as
%
%        psi(x) =    min_{y} { f(x,y) | g(x,y)<=0 } 
%        yopt   = argmin_{y} { f(x,y) | g(x,y)<=0 }
%
% where  x \in R^{nx}, y \in R^{ny}, 
%        f(x,y): R^{nx}-by-R^{ny} -> R, 
%        g(x,y): R^{nx}-by-R^{ny} -> R^{ng}.
%
% It strongly suggests that for each fixed x, both f(x,y) and g(x,y) are
% convex functions with respect to y, so that min_{y} { f(x,y) | g(x,y)<=0 } 
% is a convex program which admits a unique optimal objective function value.
%
% ------------------------------------------------------------------------- 
% Input: 
%          ny:  dimension of y, ny >= 1                                 
%        objf:  objective function, i.e., f(x,y), a function handle
%        cong:  inequality constraints, i.e., g(x,y), a function handle
%        varx:  input variable x
%          yo:  starting point of variable y, default one yo=zeros(ny,1);
% Output:
%    out.xvar:  the variable varx 
%    out.yopt:  the optimal solution   
%    out.fopt:  the optimal objective function value 
%
% -------------------------------------------------------------------------
% One simple example:
% 
%   dim   = [2 1]; % dim(1) and dim(2) = 1,2,3,..
%   rng('default'); rng(1);
%   Q     = randi(10,dim)/10;
%   objf  = @(x,y)(sum(x.^2)-sum(x.*(Q*y))+sum(y.^2));
%   cong  = @(x,y)[sum(x)+sum(y)-5; y.^2-25];
%   rng('shuffle');
%   out   = SolValFunc(dim(2),objf,cong,randn(dim(1),1)) 
%
% -------------------------------------------------------------------------
% Written by Shenglong Zhou, 06/08/2019 
% Any comments are welcome to be sent to 
%                      shenglong.zhou@soton.ac.uk
%
% Accuracy may NOT guaranteed

if nargin  < 4   
   fprintf('Inputs are not enough, no calculations!');return;
end

if  nargin < 5
    y0     = zeros(ny,1);
else
    y0     = yo;
end
opts      = optimset('Display','off');
con       = @(y)cong(varx,y);
out.yopt  = fmincon(@(y)objf(varx,y),y0,[],[],[],[],[],[],@(y)getcongnew(con,y),opts);     
out.fopt  = objf(varx,out.yopt);
out.varx  = varx;
end


%---------------------------------------------------------------------------
function [con1,con2]=getcongnew(cong,y)
con1     = cong(y); 
con2     = []; 
end

