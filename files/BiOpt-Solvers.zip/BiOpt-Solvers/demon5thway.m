clc; clear; close all; 

ExNo    = 3;
switch ExNo 
    case 1  
    data    = 2;
    dim     = [1 1 0 0];
    func    = @(x,y,keyf,keyxy)HenrionEtal2011_ver5(x,y,keyf,keyxy,data);
    case 2
    data    = AnEtal2009_data;
    dim     = [2 2 6 4];
    func    = @(x,y,keyf,keyxy)AnEtal2009_ver5(x,y,keyf,keyxy,data);
    case 3
    rate    = 0.2;           %smaller 'rate' is, larger size of 'dim'
    data    = OptimalControl_data(rate);
    dim     = [length(data.k) 2*data.ni 3 4*data.ni]; 
    func    = @(x,y,keyf,keyxy)OptimalControl(x,y,keyf,keyxy,data); 
    pars.tol= 1e-5; 
    pars.xy = -ones(dim(1)+dim(2),1);
    
end

pars.check = 1; 
pars.data  = data;   % this is required
SolNo      = 1;     % choose the solver
Solvers    = {'SNLLVF','SNQVI','SNKKT'};                                      
solver     = str2func(Solvers{SolNo});  
Out1       = solver(func, dim,  pars);
