function w=AnEtal2009_ver5(x,y,keyf,keyxy,data)
% This file provides all functions defining AnEtal2009 problem 
% and their first and second order derivatives.
% [dim_x dim_y dim_G dim_g] = [2 2 6 4]

if nargin<4 || isempty(keyxy)
    switch keyf
    case 'F';  w    = [x' y']*(data.H*[x; y]/2+data.c);
    case 'G';  w    = [-x;-y;data.A*x+data.B*y+data.d];      
    case 'f';  w    = y'*(data.P*x+data.q)+y'*data.Q*y/2; 
    case 'g';  w    = data.D*x+data.E*y+data.b;
    end    
else
    switch keyf
    case 'F'
        z    = data.H*[x; y]+data.c;
        switch keyxy
        case 'x' ; w = z(1:2,:);        
        case 'y' ; w = z(3:4,:);       
        case 'xx'; w = data.H(1:2,1:2);
        case 'xy'; w = data.H(3:4,1:2);
        case 'yy'; w = data.H(3:4,3:4);
        end 
    case 'G' 
        switch keyxy
        case 'x' ; w = [-eye(2);zeros(2);data.A];    
        case 'y' ; w = [zeros(2);-eye(2);data.B];       
        case 'xx'; w = zeros(12,2);
        case 'xy'; w = zeros(12,2);
        case 'yy'; w = zeros(12,2);
        end           
	case 'f'   
        switch keyxy
        case 'x' ; w = data.P'*y;    
        case 'y' ; w = data.P*x+data.q+(data.Q+data.Q')*(y/2);         
        case 'xx'; w = zeros(2);
        case 'xy'; w = data.P;
        case 'yy'; w = (data.Q+data.Q')/2;         
        case 'yxx'; w = [];
        case 'yxy'; w = [];
        case 'yyy'; w = [];
        end           
	case 'g' 
        switch keyxy
        case 'x' ; w = data.D;
        case 'y' ; w = data.E;             
        case 'xx'; w = zeros(8,2);
        case 'xy'; w = zeros(8,2);
        case 'yy'; w = zeros(8,2);         
        case 'yxx'; w = [];
        case 'yxy'; w = [];
        case 'yyy'; w = [];
        end        
   end   
end

end

