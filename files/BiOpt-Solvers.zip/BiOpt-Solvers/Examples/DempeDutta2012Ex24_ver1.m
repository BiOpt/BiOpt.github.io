function w=DempeDutta2012Ex24_ver1(x,y,keyf,keyxy)
% This file provides all functions defining DempeDutta2012Ex24 problem 
% and their first and second order derivatives.
% [dim_x dim_y dim_G dim_g] = [1 1 0 1]


if nargin<4 || isempty(keyxy)
    switch keyf
    case 'F'; w = (x-1)^2+y^2;
    case 'G'; w = []; 
    case 'f'; w = x^2*y;      
    case 'g'; w = y^2; 
    end    
end

end



