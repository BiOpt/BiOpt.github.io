function ffilename = CheckOutput(ExName)

    mark = isa(ExName,'function_handle');
    if  mark || strcmp(ExName(1),'@')
        if mark
        s       = func2str(ExName);
        else
        s       = ExName;    
        end
        idx1    = strfind(s,'(');
        idx2    = strfind(s,')');
        ExName  = s(idx2(1)+1:idx1(2)-1);  
    end

    filename = strcat(ExName ,'.m');
    fid      = fopen(filename,'r');
    cac      = textscan( fid, '%s', 'Delimiter','\n', 'CollectOutput',true );
    fil      = cac{1,1};    
    fclose(fid);
    copyfile(which(filename), 'tempfile.m')     
    newfid   = fopen('tempfile.m', 'w+');   
    cont     = 'w=''Need extra calculations'';';
    sfil     = size(fil,1);
    need     = 1; 
    for i    = 1:sfil
        if strcmp(fil{i},cont); need  = 0; break;  end
    end

    if need
        fprintf(newfid, '%s\n', fil{1} );
        fprintf(newfid, '%s\n', cont );
        for i        = 2:sfil
        fprintf(newfid, '%s\n', fil{i} );
        end
    end
 
     ffilename  = strcat('copy_',ExName,'.m');
     copyfile('tempfile.m', ffilename);
     fclose('all'); delete('tempfile.m');
 
     mkdir('DerivativesFile') ;
     movefile(ffilename,'DerivativesFile'); 
     ffilename = str2func(strcat('copy_',ExName));  
end