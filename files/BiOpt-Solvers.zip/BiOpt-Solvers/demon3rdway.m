clc; clear; close all; 

ExName     = 'DempeDutta2012Ex24_ver3'; 
func       = str2func(ExName);
dim        = [1 1 0 1];

pars.check = 0; 
Out1       = SNLLVF(func, dim,  pars);
Out2       = SNQVI(func, dim,  pars);
Out3       = SNKKT(func, dim,  pars);
 