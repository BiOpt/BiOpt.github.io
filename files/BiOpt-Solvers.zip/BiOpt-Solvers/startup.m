clc; clear all; close all; warning off;
addpath(genpath(pwd));