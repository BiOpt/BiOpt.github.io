clc; close all; 
ExName          = 10;  % Change the example you want to test here
                       % ExName can be can any number between [1,173]
                       % Or ExName can be the name of an example, such as
                       % ExName = 'AiyoshiShimizu1984Ex2';
[func, dim, xy] = InfomAllExamp(ExName);
if ~isa(func,'function_handle')
fprintf(['Testing example: ',func,'\n\n']);
func   = str2func(func);    
end

x   = rand(dim(1),1); 
y   = rand(dim(2),1);  

F   = func(x,y,'F',[]) 
Fx  = func(x,y,'F','x') 
Gy  = func(x,y,'G','y') 
fxy = func(x,y,'f','xy') 
gyy = func(x,y,'g','yy')