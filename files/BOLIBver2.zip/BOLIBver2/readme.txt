This BOLIBver2 folder contains the following five key elements: 
     
     [0] 'Paper.pdf' is the preprint of the paper describing the library

     [1] The folder 'Examples', which contains 
     
           1.1) 'Linear' with the m-files of 24 linear bilevel optimization examples;
           1.2) 'Nonlinear' with the m-files of 138 nonlinear bilevel optimization examples;
           1.3) 'Simple' with the m-files of 11 simple bilevel optimization examples;
           1.4) 'InfomAllExamp.m', which records infomation about all examples.
     
     [2] 'Formulas.pdf' with the mathematical formulas of all the examples. 

     [3] 'demon1.m' demonstrates one way to call an example.

     [4] 'demon2.m' demonstrates another way to to call an example.

     [5] 'startup.m' to add the library to the path.

How to use the BOLIB library:

     Step 1: Open and run 'startup.m' to add it to the path;

     Step 2: Open and run 'demon1.m' or 'demon2.m' to see how to call an example.