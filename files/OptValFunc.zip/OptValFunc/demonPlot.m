clc; clear; close all;

dim   = [2 1]; % dim(1) must be 1 or 2 and dim(2) = 0,1,2,...

if  dim(2)==0
    objf  = @(x)(sum(x.^2-x));
else
    rng('default'); rng(1);
    Q     = randi(10,dim)/10;
    objf  = @(x,y)(sum(x.^2)-sum(x.*(Q*y))+sum(y.^2));
end
cong   = @(x,y)[sum(x)+sum(y)-5; y.^2-25];
range  = [-10*ones(dim(1),1) 10*ones(dim(1),1)]; 
nox    = 100*(dim(1)==1)+20*(dim(1)>1); 
out    = PlotOVF(dim,objf,cong,range,nox);
