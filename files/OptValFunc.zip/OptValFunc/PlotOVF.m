function  out = PlotOVF(dim,objf,cong,range,nox)
% This code aims polt a value function as
%
%        \psi(x) = min_{y} { f(x,y) | g(x,y)<=0 }  
%
% where  x \in R^{nx}, y \in R^{ny}, 
%        f(x,y): R^{nx}-by-R^{ny} -> R, 
%        g(x,y): R^{nx}-by-R^{ny} -> R^{ng}.
%
% It strongly suggests that for each fixed x, both f(x,y) and g(x,y) are
% convex functions with respect to y, so that min_{y} { f(x,y) | g(x,y)<=0 } 
% is a convex program which admits a unique optimal objective function value.
%
% ------------------------------------------------------------------------- 
% Input: 
%      dim:      = [nx, ny] with nx, ny being dimensions of x and y respectively
%                NOTE: nx \in {1, 2}, other choices of nx will fail this code 
%                      ny \in {0, 1, 2, 3, ...}                                        
%      objf:     objective function, i.e., f(x,y), a function handle
%      cong:     inequality constraints, i.e., g(x,y), a function handle
%      range:    the range of x when plot \psi(x). (optional)
%                NOTE: If nx=1, range=[xmin,   xmax],   e.g., range=[-1,1];
%                      If nx=2, range=[x1min,  x1max;   e.g., range=[-1,1 ; 
%                                      x2min,  x2max]                -1,1];
%      nox:      the number of sample x. (optional)
%                Defaul ones nox = 100 when nx = 1
%                            nox = 20  when nx = 2
%                NOTE: The larger nox is, the longer the time is taken but
%                     more accurate the graph will be.
% Output:
%     out.succ:  =1 plots successfully, =0 fails to plot 
%     out.xvar:  the variable with nox elements
%                \in R^{1-by-nox}          when nx = 1     
%                \in R^{nox-by-nox-by-2}   when nx = 2    
%     out.yopt:  the optimal solutions, i.e., argmin_{y} { f(x,y) | g(x,y)<=0 }
%                \in R^{ny-by-nox}         when nx = 1     
%                \in R^{nox-by-nox-by-ny}  when nx = 2     
%     out.fopt:  the optimal objective function values with nox elements
% -------------------------------------------------------------------------
%
% One simple example:
%
%   dim   = [2 1]; % dim(1) must be 1 or 2 and dim(2) = 0,1,2,...
%   rng('default'); rng(1);
%   Q     = randi(10,dim)/10;
%   objf  = @(x,y)(sum(x.^2)-sum(x.*(Q*y))+sum(y.^2));
%   cong  = @(x,y)[sum(x)+sum(y)-5; y.^2-25];
%   range = [-10*ones(dim(1),1) 10*ones(dim(1),1)]; 
%   nox   = 100*(dim(1)==1)+20*(dim(1)>1); 
%   out   = PlotValFunc(dim,objf,cong,range,nox);
%
% -------------------------------------------------------------------------
% Written by Shenglong Zhou, 06/08/2019 
% Any comments are welcome to be sent to 
%                      shenglong.zhou@soton.ac.uk
%
% Accuracy may NOT guaranteed

 



if nargin  < 3   
   fprintf('Inputs are not enough, no calculations!');
   out.succ = 0; return;    
end


dim1 = dim(1);
dim2 = dim(2);

if dim1>2 
   fprintf('As dimension is greater than 2, can not do visualisation!');
   out.succ = 0; return;
elseif dim1 < 0 
   fprintf('Dimension is incorrect!');
   out.succ = 0; return;    
end

if  dim1==1
    symx   =  sym('x');
else    
    symx   =  sym('x',[dim1 1]); 
end

if  dim2==1
    symy   =  sym('y');
else
    symy   =  sym('y',[dim2 1]); 
end


if nargin == 3  
   range = [-ones(dim(1),1)  ones(dim(1),1)];  
   nox   = (dim(1)==1)*100+(dim(1)~=1)*20;    
end

if nargin == 4
   nox  = (dim(1)==1)*100+(dim(1)~=1)*20;
end


if dim2    > 0 
    qc     =  arrayfun(@char, cong(symx,symy), 'uniform', 0)  ;
    symcon = strcat(qc{1}, '\leq0');
    for k  = 2:length(qc)
    symcon = strcat(symcon, ', ', qc(k), '\leq0');     
    end
    Tit    = strcat('\psi(x) = min_{y}\{ ', char(objf(symx,symy)), ' | ', symcon ,' \}' );
    Tit    = Tit{1};
    Tity   = 'y^*(x) = argmin_y \{ f(x,y) | g(x,y) \leq 0 \}';
else
    Tit    = strcat('\psi(x) =  ', char(objf(symx)) );   
end

opts = optimset('Display','off'); 
disp('Please wait...');
switch dim1
    case 1 
        xmin   = range(1);
        xmax   = range(2);
        xdif   = (xmax-xmin)/(nox-1);
        f      = zeros(1,nox);    
        xvar   = zeros(1, nox);
        yopt   = zeros(dim2,nox);
        xscale = xmin:xdif:xmax;
        switch dim2
           case 0
               for i    = 1:nox
               xvar(1,i)= xscale(i);
               f(i)     = objf(xscale(i)); 
               end                 
            otherwise
                warning off;
                y0    = zeros(dim(2),1);
                obj   = objf;   
                con   = @(x,y)cong(x,y);   
                yx    = @(x)fmincon(@(y)obj(x,y),y0,[],[],[],[],[],[],@(y)getcong(con,x,y),opts );     
                for i = 1:nox
                    x        = xscale(i);
                    xvar(1,i)= x;
                    yopt(:,i)= yx(x); 
                    f(i)     = objf(x,yopt(:,i));        
                end
        end
        
        disp('Start to plot...');
        figure;
        plot(xscale,f,'r-'); 
        if min(f)~=max(f)
        axis([xmin xmax  min(f)-0.05*abs(min(f)) max(f)+0.05*abs(max(f))]);
        end
        xlabel('x');  ylabel('\psi(x)'); set(gca,'FontSize',9); grid on       
        if  dim2 < 4
            title(Tit,'FontWeight','normal','FontSize',10-dim2);
        else
            Tit='\psi(x) = min_y \{ f(x,y) | g(x,y) \leq 0 \}';
            title(Tit,'FontWeight','normal','FontSize',10);    
         end
        
                
        if dim2==1
        figure
        plot(xscale,yopt,'r-'); 
        if min(yopt)~=max(yopt)
        axis([xmin xmax min(yopt)-0.05*abs(min(yopt)) max(yopt)+0.05*abs(max(yopt))]);
        end
        xlabel('x'); ylabel('y^*(x)');  
        set(gca,'FontSize',9); grid on
        title(Tity,'FontWeight','normal','FontSize',10-dim2);   
        end     
        
        
    case 2
        x1min   = range(1,1);
        x1max   = range(1,2);
        x2min   = range(2,1);
        x2max   = range(2,2);
        x1dif   = (x1max-x1min)/(nox-1);
        x2dif   = (x2max-x2min)/(nox-1);
        f       = zeros(nox,nox);        
        xvar    = zeros(nox,nox,dim(1));
        y       = zeros(dim(2),1);
        yopt    = zeros(nox,nox,dim(2));
        x1scale = x1min:x1dif:x1max;
        x2scale = x2min:x2dif:x2max;
        [X1,X2] = meshgrid(x1scale,x2scale);
        
        switch dim2
           case 0
               for i  = 1:nox
               for j  = 1:nox
               xvar(i,j,:)= [X1(i,j);X2(i,j)];
               f(i,j)     = objf([X1(i,j);X2(i,j)]); 
               end
               end
            otherwise
                warning off;
                y0    = zeros(dim(2),1);
                obj   = objf;   
                con   = @(x,y)cong(x,y);   
                yx    = @(x)fmincon(@(y)obj(x,y),y0,[],[],[],[],[],[],@(y)getcong(con,x,y),opts);     
                for i = 1:nox
                for j = 1:nox
                    x           = [X1(i,j);X2(i,j)];
                    xvar(i,j,:) = x;
                    yopt(i,j,:) = yx(x); 
                    y(:)        = yopt(i,j,:);
                    f(i,j)      = objf(x,y);
                     
                end
                end                
        end 
        
        disp('Start to plot...');
        
        figure
        surfc(X1,X2,f,'FaceAlpha',1); 
        xlabel('x_1'); ylabel('x_2'); zlabel('\psi(x)'); set(gca,'FontSize',9);
        if  dim2 < 4
            title(Tit,'FontWeight','normal','FontSize',10-dim2);
        else
            Tit='\psi(x) = min_y \{ f(x,y) | g(x,y) \leq 0 \}';
            title(Tit,'FontWeight','normal','FontSize',10);    
         end
       
        figure
        contour(X1,X2,f,10,'ShowText','on','LineWidth',0.5,'LabelSpacing',1000);
        xlabel('x_1'); ylabel('x_2'); set(gca,'FontSize',9);
        
        if dim2==1
        figure
        surfc(X1,X2,yopt,'FaceAlpha',1);
        xlabel('x_1'); ylabel('x_2'); zlabel('y^*(x)') ;
        set(gca,'FontSize',9);
        title(Tity,'FontWeight','normal','FontSize',10-dim2);
        end
         
end
disp('Done plotting !!!');
out.succ =  1;
out.fopt =  f;
if  dim2 >  0
out.yopt =  yopt;
end
out.xvar =  xvar;
end

%---------------------------------------------------------------------------
function [con1,con2]=getcong(cong,x,y)
con1     = cong(x,y); 
con2     = []; 
end