clc; clear; close all;

dim   = [200 400]; 
rng('default'); rng(1);
Q     = randi(10,dim)/10;
objf  = @(x,y)(sum(x.^2)-sum(x.*(Q*y))+sum(y.^2));
cong  = @(x,y)[sum(x)+sum(y)-5; y.^2-25];
out   = SolOVF(dim(2),objf,cong,randn(dim(1),1)) 
