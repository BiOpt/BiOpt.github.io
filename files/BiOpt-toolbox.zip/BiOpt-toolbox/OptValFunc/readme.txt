
This OptValFunc folder at least contains 1 txt-file,  and 4 m-files:

        [1] Folder DerivativesFolder contains all calculated derivatives files
     
        [2] 'SolOVF..m':     the main fucntion that is to be used to solve an optimal-value function.

        [3] 'PlotOVF.m':     the main fucntion that is to be used to plot an optimal-value function.

        [4] 'demonSol.m':  demonstrate 'SolValFunc.m' how to solve an optimal-value function.
	
        [5] 'demonPlot.m': demonstrate 'SolValFunc.m' how to plot an optimal-value function.


How to use this tool:

        Open  and run 'demonSol.m'  to see 'SolOVF.m'  solving an optimal-value function, or
      
        Open  and run 'demonPlot.m' to see 'PlotOVF.m' plotting an optimal-value function.