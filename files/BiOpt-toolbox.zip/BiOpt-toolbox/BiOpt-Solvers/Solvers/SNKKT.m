function Out = SNKKT(func,dim,pars)
% This code aims to solve the bilevel optimization in the form
%
%          min_{x,y}  F(x,y)  s.t. G(x,y)<=0, 
%                                  y \in argmin_y { f(x,y): g(x,y)<=0 }
%
% where x \in R^{n_x}, y \in R^{n_y}, G(x,y)\in R^{n_G}, g(x,y)\in R^{n_g}  
% with n_x>0, n_y>0, n_G>=0 and n_g>=0.
%
% Input:
%     dim : A row (or column) vector with FOUR elements, i.e., dim=[n_x n_y n_G n_g] 
%     func: A function handle (or a string) must contain Four functions [F G f g], (required)
%           preferably including 1st and 2nd order derivatives of F,G,f and g,     (optional)
%                                3rd order derivatives of f and g                  (optional)
%     pars: Starting point, parameters and other information. 
%           All are optional except for pars.data
%           pars.xy:     The starting point for x and y, i.e.,pars.xy=[x0;y0]                     
%                        It is a COLUMN vector whose dimension is (n_x+n_y)
%                        Default one pars.xy=zeros(n_x+n_y,1)
%           pars.lam:    A positive penalty parameter, default one pars.lam=1 
%                        NOTE: It is an important parameter  
%                        Different choices may produce  different results
%           pars.varlam: allow pars.lam to be varied if pars.varlam=1 (default)
%                        fix pars.lam  if pars.varlam=0 
%           pars.check:  Check the completeness of all 1st,2nd order derivatives
%                        of F, G, f and g and 3rd order derivatives of f and g 
%                        =1 does check (default), =0 does not check
%           pars.iterin: Show results for each iteration if pars.iteron=1 (default)
%                        Don't show results for each iteration if pars.iteron=0  
%           pars.maxit:  Maximum iteration number, default one  pars.maxit=2000
%           pars.tol:    Tolerance for the stopping criteria, default one pars.tol=1e-8
%           pars.draw:   A  graph will be drawn if pars.draw=1  
%                        No graph will be drawn if pars.draw=0 (default)
%           pars.data:   This extra data is relied on the example that will be solved. 
%                        If one example does not need extra data, then no need pars.data  
%                        Otherwise, input the data. The latter case means nargin(func)=5  
%           pars.keep:   This is only valid when pars.check=1
%                        =1, keep all calculated derivatives in DerivativesFile folder 
%                        =0, delete all calculated derivatives in DerivativesFile folder (default) 
%
% Output:
%     Out.x:             Solution x
%     Out.y:             Solution y
%     Out.F:             Upper level objective function value
%     Out.f:             Lower level objective function value
%     Out.time:          CPU time
%     Out.iter:          Number of iterations
%     Out.error:         Error 
%
%
%%%%%%%    Send your comments and suggestions to                     %%%%%%
%%%%%%%    shenglong.zhou@soton.ac.uk                                %%%%%%
 
%%%%%%%    Warning: Accuracy may not be guaranteed!!!!!              %%%%%%

%%%%%%%    This version: July 30, 2019                               %%%%%%

%%%%%%%    written by Shenglong Zhou                                 %%%%%% 

clock  = tic;
warning off; 

if nargin<2 
   error('No enough inputs\n'); 
end   
 
if length(dim)~=4
   fprintf('Dimensions are incorrect, please input again\n'); return;
end

if nargin==2 
   pars.lam = 1; % an important parameter
end

if isfield(pars,'lam');    pars.lam = pars.lam;  else; pars.lam = 1;  end
if isfield(pars,'iteron'); iteron = pars.iteron; else; iteron = 1;    end
if isfield(pars,'draw');   draw   = pars.draw;   else; draw   = 0;    end
if isfield(pars,'keep');   keep   = pars.keep;   else; keep   = 0;    end
if isfield(pars,'maxit');  maxit  = pars.maxit;  else; maxit  = 2000; end
if isfield(pars,'tol');    errtol = pars.tol;    else; errtol = 1e-8; end
if isfield(pars,'check');  check  = pars.check;  else; check  = 1;    end
if isfield(pars,'varlam'); varlam = pars.varlam; else; varlam = 1;    end 

if  isa(func,'function_handle')
    strfunc   = func2str(func); 
    nonarginf = nargin(func); 
else
    strfunc   = func;
    func      = str2func(func);
    nonarginf = nargin(func);     
end 

if  nonarginf==5 
    if ~isfield(pars,'data');  error('Input data is missing...');  end
end

if  check    
    copyfunc = CheckOutput(strfunc); 
    if exist('DerivativesFile')
       addpath('DerivativesFile') ; 
    end
    
    if  isa(copyfunc,'function_handle')
        copyfunc=func2str(copyfunc);
        copyfunc=str2func(copyfunc); 
    else
        copyfunc=str2func(copyfunc); 
    end
    
    if nonarginf ~= nargin(copyfunc)
        if ~isfield(pars,'data');  error('Input data is missing...');  end
        nonarginf = nargin(copyfunc);
    end
    if  nonarginf<5 
        mark     = CompleteDerivatives(copyfunc,dim,'fg');
    else                  
        mark     = CompleteDerivatives(copyfunc,dim,'fg',pars.data);  
        copyfunc = @(varx,vary,keyf,keyxy)copyfunc(varx,vary,keyf,keyxy,pars.data);
    end    
    fun = @(varx,vary,keyf,keyxy)GetDerivatives(varx,vary,keyf,keyxy,copyfunc,mark); 
else    
    if  nonarginf<5
        fun=func;           
    else
        fun = @(varx,vary,keyf,keyxy)func(varx,vary,keyf,keyxy,pars.data);
    end   
end

sigma  = 1e-6;
beta   = 1e-8; 
t      = 1.05;
NoArmi = 6; 
J      = NoArmi;
alpha0 = 2;

 
num    = getnumber(dim);
if isfield(pars, 'xy')
x      = pars.xy(1:num(1),:);
y      = pars.xy(num(1)+1:num(2),:);
else       
x      = zeros(dim(1),1);
y      = zeros(dim(2),1);
end
             
X         = getstartpoint(x,y,fun,num,dim);
pars.num  = num;
pars.dim  = dim;
P         = Phi(fun, X, pars ); 
Error     = FNorm(P);  
pars.lam0 = pars.lam ;
 
Err       = Inf*ones(maxit,1);
XX        = zeros(3,1);
F0        = 1e6*abs(fun(x,y,'F',[])); 
nX        = length(P);
flag1     = 0; 
flag2     = 0;
flag3     = 1;
fluct     = zeros(maxit,1);
Obj       = zeros(maxit,2);

fprintf('\n\nStart to run SNKKT solver...');
fprintf('\n--------------------------------------------\n');
if  iteron 
    fprintf('\nIter    Upper-Obj    Lower-Obj      CPU-Time');   
    fprintf('\n--------------------------------------------\n');    
end

for iter    =  1:maxit 
         
    W       =  Jacobian_Phi(fun, X, pars);  
    WP      =  (P'*W)'; 
    if nX   >  1e4
    d       = -pcg(W,P,1e-6,100);
    else
    d       = -W\P;      
    end
    Error0  =  Error;
    re      =  Inf*ones(1,4);
    for i   =  1:4        
        if  max(isnan(d))==1 || FNorm(d) > max(1e10,F0) || flag1
            if     i<=2 ; WW = W'*W; WWI  = WW;
                          WWI(1:1+nX:end) = WWI(1:1+nX:end)+1e-6*min(1,Error);
                          if nX>=1000; [d,~] = pcg(WWI,-WP,1e-6,100 );   
                          else;       d  = -WWI\WP;
                          end
            elseif i==3 ; [d,~] = pcg(WW,-WP,1e-6,100 );
            end
        end 
        
        Normd        =  FNorm(d);
        WPd          =  sum(sum(WP.*d)); %     
        if flag1 && i == 4           
           WPdg      =  sum(sum(WP.*WP));  
           if (WPd    > -beta*Normd^t && WPd>-WPdg)  || isnan(WPd)      
              WPd    = -WPdg;  
              d      = -WP;           
           end          
        end
 
        if iter>5
            rate         = sqrt(Normd)/(NormX+1);    
            if  rate     > 1e2 
                alpha0   = 1/sqrt(rate);   
                J        = NoArmi; 
                flag2     = 0;
            elseif rate  < 1e-6 && rate > 1e-10 && Error > 1e-4 
                alpha0   = 1/rate;      
                J        = ceil(log2(alpha0))+ NoArmi;   
                flag2     = 0;
            end
   
            if  rate >= 1e-6 && rate <=1e2 && (mod(iter,10)==0 || ~flag2)
                if Error < errtol/10
                    alpha0   = 1;       
                    J        = NoArmi; 
                elseif iter  > 10 && sum(fluct(iter-10:iter-1))>=3 
                    alpha0   = 2;         
                    J        = NoArmi+5; 
                else
                    alpha0   = 2;       
                    J        = NoArmi;                
                end
                flag2         = 1; 
            end
        end       
 
        alpha        = alpha0;   
        j            = 1;         
        while j     <= J
            Xnew     = X + alpha*d;   
            P        = Phi(fun,Xnew,pars );  
            Error    = FNorm(P);   
            if Error < Error0+sigma*alpha*WPd; break;  end    
            alpha    = alpha*0.5;
            j        = j+1;
            if j >J && Error/Error0>1e8
            J        = NoArmi+5; 
            end
        end 
 
        if (j>J && Error/Error0>1e4) || Normd<1e-8
            Xnew1  = X - alpha*WP;      
            P1     = Phi(fun,Xnew,pars );   
            Error1 = FNorm(P);     
            if Error1 > Error 
            Xnew   = Xnew1;  
            P      = P1;   
            Error  = Error1;  
            end
        end
        
        gap       = 0;
        re(i)     = Error;              
        if i>1   && re(i) < re(i-1)
           Err0   = re(i);   
           alp0   = alpha; 
           P0     = P; 
           Xn0    = Xnew;  
           gap    = gap+1; 
        end
      
        if Error  < 1e6*max(1,Error)*Error0
            flag1  = 0; break;  
        else              
            flag1  = 1;            
        end    
    end
 
    if gap
       Error  = Err0;  
       alpha  = alp0;
       P      = P0;
       Xnew   = Xn0;               
    end
 
    if Error>Error0; fluct(iter)=1; end
    
    NormX      = sqrt(FNorm(Xnew)); 
    Err(iter)  = sqrt(Error);
    if  iter   > 100 && iter  < maxit-100  && flag3==1 
        Ind    = iter-99:iter;
        sq     = Err(Ind); 
        stdErr = std(sq); 
        msq    = max(sq); 
        cond1  = (mod(iter,500)==0 && sum(fluct(Ind))>20); 
        cond2  = (rate<1e-6); 
        cond3  = (stdErr<1e-2*msq); 
        cond4  = (sq(end)> 100*errtol); 
    if  isnan(NormX) || ( cond4 && (cond1 || cond2 || cond3) ) 
        x        = X(1:num(1),:);
        y        = X(num(1)+1:num(2),:)*log10(iter); 
        Xnew     = getstartpoint(x,y,fun,num,dim);       
        pars.lam = pars.lam0/log10(iter);         
        P        = Phi(fun,Xnew,pars);     
        Error    = FNorm(P);       
        flag3    = 0; 
        iter0    = iter;
    else
        pars.lam = pars.lam0; 
        flag3    = 1; 
    end
    end

    if  flag3==0 &&  iter == iter0+50
        flag3=1;
    end
        
    XX         = [XX(2:3); sqrt(FNorm(Xnew-X))];  
    X          = real(Xnew); 
    P          = real(P);
    Err(iter)  = sqrt(Error);
    vx         = X(1:num(1),:);
    vy         = X(num(1)+1:num(2),:);
    F          = fun(vx,vy,'F',[]);
    f          = fun(vx,vy,'f',[]);
    Obj(iter,:)= [F f]; 
    if  iteron 
        fprintf('%4d     %8.3f     %8.3f     %6.2fsec\n',iter, F, f, toc(clock));
    end

    if  pars.lam == pars.lam0 
        if Err(iter)<errtol
           break;
        elseif Err(iter)<1e-2           
           if  iter>100 && stdErr<1e-6
               fprintf('\n--------------------------------------------');
               fprintf('\nError didn''t change for last 100 iterations!')
               break;   
           end          
           if  iter>50
               stdObj=std(Obj(iter-50:iter,1)/abs(Obj(iter,1)));
               stdobj=std(Obj(iter-50:iter,2)/abs(Obj(iter,2)));
               if max(stdObj,stdobj)<1e-6
               fprintf('\n--------------------------------------------');
               fprintf('\nObjectives didn''t change for last 50 iterations!')
               break; 
               end
           end       
        end 
    elseif pars.lam ~= pars.lam0  
        if Err(iter)<errtol
           if  varlam 
               break;
           else 
               pars.lam = pars.lam0;
               flag3    = 0;
           end
        end
    end
    
    
end
 
fprintf('\n--------------------------------------------'); 
Out.x     = X(1:num(1),:); 
Out.y     = X(num(1)+1:num(2),:);
Out.z     = X(num(2)+1:num(3),:);
Out.s     = X(num(3)+1:num(4),:);
Out.u     = X(num(4)+1:num(5),:);
Out.v     = X(num(5)+1:num(6),:);
Out.w     = X(num(6)+1:num(7),:);
Out.F     = fun(Out.x,Out.y,'F',[]);  
Out.f     = fun(Out.x,Out.y,'f',[]) ; 

if iter>2
Out.EOC   = max(log(XX(3))/log(XX(2)),log(XX(2))/log(XX(1)));
elseif iter==2 
Out.EOC   = log(XX(3))/log(XX(2));
else
Out.EOC   = Inf;
end
Out.iter  = iter;
Out.time  = toc(clock);
Out.error = Err(iter);
Out.alpha = alpha; 

if  max(dim(1),dim(2))<=10 
    fprintf('\nx      = ');
    for i=1:dim(1);      fprintf('%10.4f ', Out.x(i) ); end
    fprintf('\ny      = ');
    for i= 1:dim(2);  fprintf('%10.4f ', Out.y(i) ); end
end


fprintf('\nF(x,y) = %10.4f \n',  Out.F );
fprintf('f(x,y) = %10.4f \n', Out.f );

fprintf('Error  = %10.2e  \n', Out.error);
fprintf('Iter   = %10d  \n', iter);
fprintf('Time   = %10.4f sec\n\n', Out.time);

   infG  = 0; 
if dim(3)> 0 
   G0    = fun(Out.x,Out.y,'G',[]);
   infG  = nnz(find(G0(G0>5e-3)));
end
   infg  = 0;
if dim(4)> 0
   g0    = fun(Out.x,Out.y,'g',[]); 
   infg  = nnz(find(g0(g0>5e-3)));
end

if infG || infg 
    fprintf('\n-----------------------\n');
    fprintf('Solution is infeasible!'); 
    fprintf('\n-----------------------\n');
end

Out.feasible=~(infG || infg );

 if draw
    LastIt=20;
    figure
    if iter<=LastIt 
        plot(1:iter,Err(1:iter,1)); grid on
        xlabel('Iter'); hold on
    else
        LT=iter-LastIt+1:iter;
        plot(LT,Err(LT,1)); hold on
        xlabel('Last 20 iterations'); grid on
    end
    
    ylabel('Error')
 end 
 

 if ~keep && exist('DerivativesFile','dir')
    mkdir('DerivativesFile')
    rmdir('DerivativesFile','s')
 end
 
end


% ========================================================================
function num=getnumber(dim)
dim0   = [dim(1) dim(2) dim(4) dim(2) dim(3) dim(4) dim(4)];
num    = [dim0(1) zeros(1,6)];
for i=2:7
num(i) = num(i-1)+dim0(i);
end
end

% ========================================================================
function X=getstartpoint(x,y,fun,num,dim)
nX                   = num(end);
X                    = zeros(nX,1);
X(1:num(1),:)        = x;
X(num(1)+1:num(2),:) = y;

if dim(3)>0
fGxy                 = fun(x,y,'G',[]);
X(num(4)+1:num(5),:) = abs(fGxy); 
end

if dim(4)>0
fgxy                 = fun(x,y,'g',[]);
X(num(2)+1:num(3),:) = -abs(fgxy);
X(num(5)+1:num(6),:) = abs(fgxy);
X(num(6)+1:num(7),:) = abs(fgxy);       
end
end

% ========================================================================
function FNorm_x = FNorm( x )
 FNorm_x = sum(sum(x.*x));
end

% ========================================================================
function  phi = Phi(fun,X,pars )

num   = pars.num;
dim   = pars.dim;
lam   = pars.lam;
x     = X(1: num(1),:);
y     = X(num(1)+1:num(2),:);
z     = X(num(2)+1:num(3),:);
s     = X(num(3)+1:num(4),:);
u     = X(num(4)+1:num(5),:);
v     = X(num(5)+1:num(6),:);
w     = X(num(6)+1:num(7),:); 

if dim(3)>0 
    Gx  = fun(x,y,'G','x');
    Gy  = fun(x,y,'G','y');
else
    Gx  = 0;
    Gy  = 0; 
    u   = 0;
end

if dim(4)>0 
    g   = fun(x,y,'g',[]);
    gx  = fun(x,y,'g','x');
    gy  = fun(x,y,'g','y');
    gxy = fun(x,y,'g','xy');
    gyy = fun(x,y,'g','yy');
else
    g   = 0;
    gx  = 0;
    gy  = 0;
    gxy = [];
    gyy = [];
    z   = 0;
    w   = 0;
    v   = 0;
end

JLx  = fun(x,y,'F','x') + Gx'*u + gx'*(lam*z + v) + ... 
       ( fun(x,y,'f','xy') - JuTf(z,gxy) )'*s;
JLy  = fun(x,y,'F','y') + Gy'*u + gy'*(lam*z + v) + ...
       ( fun(x,y,'f','yy') - JuTf(z,gyy) )'*s;
                   
Jlz  =  lam*g + w -  gy*s;

h    = fun(x,y,'f','y')-gy'*z;

if dim(3)>0 
    Gu   = FB_fun(u,-fun(x,y,'G',[]));
end

if dim(4)>0 
    gv  = FB_fun(v,-fun(x,y,'g',[]));
    zw  = FB_fun(w,-z);
end

if     dim(3)>0 && dim(4)>0
       phi  = [JLx; JLy; Jlz; h; Gu; gv; zw];
elseif dim(3)==0 && dim(4)>0
       phi  = [JLx; JLy; Jlz; h; gv; zw];  
elseif dim(3)>0 && dim(4)==0
       phi  = [JLx; JLy; h; Gu]; 
else
       phi  = [JLx; JLy; h];
end

phi  = real(phi);
end

% ========================================================================
function JPhi = Jacobian_Phi(fun,X,pars )

num   = pars.num;
dim   = pars.dim;
lam   = pars.lam;
x     = X(1: num(1),:);
y     = X(num(1)+1:num(2),:);
z     = X(num(2)+1:num(3),:);
s     = X(num(3)+1:num(4),:);
u     = X(num(4)+1:num(5),:);
v     = X(num(5)+1:num(6),:);
w     = X(num(6)+1:num(7),:); 

nx    = dim(1);
ny    = dim(2);
nG    = dim(3);
ng    = dim(4);

if ng > 0
    gxx = fun(x,y,'g','xx');
    gxy = fun(x,y,'g','xy');
    gyy = fun(x,y,'g','yy');
else
    gxx = [];
    gxy = [];
    gyy = [];
end
 
JLxx = fun(x,y,'F','xx')+ JuTf(u,fun(x,y,'G','xx')) + JuTf(lam*z+v,gxx)+ ...
       JuTf( s,fun(x,y,'f','yxx') ) - zs3rdg( z, s, fun(x,y,'g','yxx') );
JLxy = fun(x,y,'F','xy')+ JuTf(u,fun(x,y,'G','xy')) + JuTf(lam*z+v,gxy)+ ...
       JuTf( s,fun(x,y,'f','yxy') ) - zs3rdg( z, s, fun(x,y,'g','yxy'));    
if  ng  > 0
    sgx = zeros(ng,nx);
    if ~isempty(gxy)
        for i=1:ng
        sgx(i,:)=s'*gxy(1+(i-1)*ny:i*ny,:);
        end
    end
    JLxz = lam*fun(x,y,'g','x') - sgx;
end
JLxs = fun(x,y,'f','xy') - JuTf(z,gxy);
JLxu = fun(x,y,'G','x');
JLxv = fun(x,y,'g','x');
JLxw = zeros(ng,nx);


JLyy = fun(x,y,'F','yy') + JuTf(u,fun(x,y,'G','yy')) + JuTf(lam*z+v,gyy)+ ...
       JuTf( s,fun(x,y,'f','yyy') ) - zs3rdg( z, s, fun(x,y,'g','yyy') );
if  ng  > 0
    sgy = zeros(ng,ny);
    if ~isempty(gxy)
        for i=1:ng
        sgy(i,:)= s'*gyy(1+(i-1)*ny:i*ny,:);
        end
    end
    JLyz = lam* fun(x,y,'g','y') -sgy;
end
JLys = fun(x,y,'f','yy')- JuTf(z,gyy);
JLyu = fun(x,y,'G','y'); 
JLyv = fun(x,y,'g','y'); 
JLyw = zeros(ng,ny);

if ng>0
JLzz =  zeros(ng,ng);
JLzs = -fun(x,y,'g','y')'; 
JLzu =  zeros(nG,ng);
JLzv =  zeros(ng,ng);
JLzw =  eye(ng); 
end

JLss =  zeros(ny,ny);
JLsu =  zeros(nG,ny);
JLsv =  zeros(ng,ny);
JLsw =  zeros(ng,ny); 

if nG>0  
[JGuu,JGux,JGuy]=Diff_ugxy(u,fun(x,y,'G',[]),JLxu,JLyu);
JGuv = zeros(ng,nG);
JGuw = zeros(ng,nG);
end

if ng>0   
[Jgvv,Jgvx,Jgvy] = Diff_ugxy(v,fun(x,y,'g',[]),JLxv,JLyv);
Jgvw = zeros(ng,ng);
[Jgww,Jgwz,~]    = Diff_ugxy(w,z,JLzw,JLzw);
end


if nG>0 && ng>0     
JPhi=[JLxx  JLxy'  JLxz'  JLxs'  JLxu'  JLxv'  JLxw'; 
      JLxy  JLyy   JLyz'  JLys'  JLyu'  JLyv'  JLyw'; 
      JLxz  JLyz   JLzz   JLzs'  JLzu'  JLzv'  JLzw'; 
      JLxs  JLys   JLzs   JLss   JLsu'  JLsv'  JLsw'; 
      JGux  JGuy   JLzu   JLsu   JGuu   JGuv'  JGuw'; 
      Jgvx  Jgvy   JLzv   JLsv   JGuv   Jgvv   Jgvw'; 
      JLxw  JLyw   Jgwz   JLsw   JGuw   Jgvw   Jgww];
elseif nG==0 && ng>0 
JPhi=[JLxx  JLxy'  JLxz'  JLxs'  JLxv'  JLxw'; 
      JLxy  JLyy   JLyz'  JLys'  JLyv'  JLyw'; 
      JLxz  JLyz   JLzz   JLzs'  JLzv'  JLzw'; 
      JLxs  JLys   JLzs   JLss   JLsv'  JLsw'; 
      Jgvx  Jgvy   JLzv   JLsv   Jgvv   Jgvw'; 
      JLxw  JLyw   Jgwz   JLsw   Jgvw   Jgww];
elseif nG>0 && ng==0 
JPhi=[JLxx  JLxy'  JLxs'  JLxu'; 
      JLxy  JLyy   JLys'  JLyu';  
      JLxs  JLys   JLss   JLsu'; 
      JGux  JGuy   JLsu   JGuu];
else
JPhi=[JLxx  JLxy'  JLxs'; 
      JLxy  JLyy   JLys'; 
      JLxs  JLys   JLss];
end

JPhi= real(JPhi);

end




% ========================================================================
function Juf = JuTf(u,Jf) 
    if ~isempty(Jf)
        m     = size(u,1);
        nx    = size(Jf,2);
        ny    = size(Jf,1)/m;
        Juf   = zeros(ny,nx);
        for i = 1:m
        Juf   = Juf+ u(i)*Jf( (1+(i-1)*ny):(i*ny),: );
        end
        Juf   = real(Juf);
    else
        Juf   = 0;
    end
end

% ========================================================================
function zsg  =zs3rdg(z, s, D)

    if ~isempty(D)
        ng  = length(z);
        ny  = length(s);
        row = size(D,1)/ng; 
        col = size(D,2)/ny;
        zsg = zeros(row,col);
        for i=1:ng
            for j=1:ny
               zsg=zsg+(z(i)*s(j))*D(1+(i-1)*row:i*row,1+(j-1)*col:j*col);
            end
        end                         
    else
        zsg   = 0;
    end
    
end

% ========================================================================
function FB=FB_fun(a,b)
ab = a+b;
FB = sqrt(a.*a+b.*b)-ab ;
T  = find(ab>0);
FB(T)=-2*a(T).*b(T)./(FB(T)+2*ab(T));
end

% ========================================================================
function [Jguu,Jgux,Jguy]=Diff_ugxy(u,gxy,Jgx,Jgy)
aug  = u.^2+gxy.^2;
T    = find(aug<1e-4);
Tc   = find(aug>=1e-4);
jguu = u;
jgxy = u;
s    = sum(Jgx,2)+sum(Jgy,2);

if ~isempty(T)
    ss     = sqrt(1+s(T).^2);
    jguu(T)= 1./ss-1;
    jgxy(T)= s(T)./ss+1;
end

if ~isempty(Tc)
    sug     = sqrt(aug(Tc));
    jguu(Tc)= u(Tc)./sug-1;
    jgxy(Tc)= gxy(Tc)./sug+1;
end

Jguu = diag(jguu);
Jgux = diag(jgxy)*Jgx;
Jguy = diag(jgxy)*Jgy;

end

% ========================================================================
function w = GetDerivatives(x,y,keyf,keyxy,fun,mark)

if  isempty(keyxy)
    w = fun(x,y,keyf,[]); 
else
    keyf0  = {'F', 'G', 'f', 'g'};
    for i  = 1:4
    if  isequal(keyf0{i},keyf); break; end
    end
    
    keyf0  = {'F1', 'G1', 'f', 'g'};
    keyxy0 = {'x', 'y', 'xx', 'xy', 'yy', 'yxx', 'yxy', 'yyy'};
    for j  = 1:8
    if  isequal(keyxy0{j},keyxy); break; end
    end
    
    if mark(i,j)==1 
        w = fun(x,y,keyf,keyxy);
    elseif mark(i,j)==2
        w = [];
    else  
        if length(x)<=20 && length(y)<=20
        filename  = str2func(strcat(keyf0{i}, keyxy)); 
        w         = filename(x,y);
        else
        varx      = sym('x',[length(x),1]);
        vary      = sym('y',[length(y),1]);
        filename  = strcat(strcat(keyf0{i}, keyxy),'.mat'); 
        load(filename);
        fw        = @(vx,vy)double(subs(symFfxy,[varx;vary],[vx;vy])); 
        w         = fw(x,y);
        end
    end
end

end