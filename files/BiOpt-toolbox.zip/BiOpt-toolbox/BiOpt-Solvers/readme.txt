
This BiOpt-solvers folder contains 1 txt file, 2 folders and 7 m files:

     [1] Toolbox folder contains three solves and some useful functions
 
     [2] Examples folder contains some examples that are used to do demonstration.

     [3] startup.m' adds the path to current- and sub- folders; 

     [4] 'demonXXX.m' demonstrates solvers to solve different examples from folder 'Examples';


How to use this BiOpt-solvers:

     Step 1: Open and run 'startup.m' to add  the path;
     
     Step 2: Open and run 'demonXXX.m' to see solvers to solve different examples from folder 'Examples';
