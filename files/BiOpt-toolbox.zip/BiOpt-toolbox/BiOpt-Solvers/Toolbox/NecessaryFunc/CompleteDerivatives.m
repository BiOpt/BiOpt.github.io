function  mark = CompleteDerivatives(func,dim,status,data)

%  check the first, second and third derivatives of input functions
%  func    = @(x,y){F(x,y), G(x,y), f(x,y), g(x,y)}
%  dim     = [n_x n_y n_f n_g] 
%  STATUS  = 'fg', need calculate 3rd derivatives of f and g
%          = 'f',  need calculate 3rd derivatives of f 
%          = [],   no need calculate 3rd derivatives

if exist('DerivativesFile')
   addpath('DerivativesFile') ;
end
            
clock  = tic; 

keyf   = {'F',  'G',  'f', 'g'};
keyf1  = {'F1', 'G1', 'f', 'g'};

if nargin<3; status=[]; end

if isequal(status, 'fg') || isequal(status, 'f')  
keyxy  = {'x', 'y', 'xx', 'xy', 'yy', 'yxx', 'yxy', 'yyy'};
else                                     
keyxy  = {'x', 'y', 'xx', 'xy', 'yy'};
end

nf        = length(keyf);
nxy       = length(keyxy);
varx      = sym('x',[dim(1),1]);
vary      = sym('y',[dim(2),1]);
mark      = zeros(nf,nxy);
 

fprintf('\nCheck the completeness of all derivatives\n');
for i     = 1:nf
    miss  = zeros(nxy,1); 
    if nargin<4  
        funF  = @(vx,vy)func(vx,vy,keyf{i},[]);          % define (F G f g)
    else
        funF  = @(vx,vy)func(vx,vy,keyf{i},[],data);
    end
    for j = 1:nxy
        if (i==2 && dim(3)==0)|| (i==4 && dim(4)==0)         % No G or no g
            mark(i,j)=2;
        else            
            if nargin< 4
            miss(j)  = isequal(func(rand(dim(1),1),rand(dim(2),1),keyf{i},keyxy{j}),'Need extra calculations'); 
            else
            miss(j)  = isequal(func(rand(dim(1),1),rand(dim(2),1),keyf{i},keyxy{j},data),'Need extra calculations');
            end
            if  miss(j) == 1                  
                if  j < 6
                    fprintf('Calculate derivative of %s w.r.t %3s \n', keyf{i}, keyxy{j} ) 
                    symFfxy    = Diff1st2nd(funF, dim, keyxy{j}); 
                    if isequal(status, 'fg') || isequal(status, 'f') 
                       if     isequal(keyxy{j},'xy'); tempxy = symFfxy;  
                       elseif isequal(keyxy{j},'yy'); tempyy = symFfxy;   
                       end
                    end
                else
                    if  (isequal(status, 'fg') && (keyf{i}=='f' || keyf{i}=='g')) || ...
                        (isequal(status, 'f')  &&  keyf{i}=='f')   
                        if  isequal(keyxy{j},'yxx') %|| isequal(keyxy{j},'yxy') 
                            if  miss(4); symFfxy  =  tempxy;    
                            else;        symFfxy  =  Diff1st2nd(funF, dim, 'xy'); 
                            end
                        else
                            if  miss(5); symFfxy  =  tempyy;     
                            else;        symFfxy  =  Diff1st2nd(funF, dim, 'yy'); 
                            end   
                        end 
                        X   = has(symFfxy,varx);  
                        Y   = has(symFfxy,vary);
                        cal = (max(X(:))==1 || max(Y(:))==1);
                        fprintf('Calculate derivative of %s w.r.t %3s \n', keyf{i}, keyxy{j} );                        
                        if cal; symFfxy = Diff3rd(symFfxy, dim, keyxy{j});  
                        else;   mark(i,j)=2;  
                        end
                        clear X Y;
                    else
                    mark(i,j)= 2;   
                    end
                end 
            else
                mark(i,j)= 1;
            end
        end 
         
        if  mark(i,j)==0 
        if  dim(1)<=20 && dim(2)<=20
            filename = strcat(strcat(keyf1{i}, keyxy{j}),'.m'); 
            if ~isempty(symFfxy)
            matlabFunction(symFfxy,'vars', {varx, vary}, 'file', filename); 
            else
            mark(i,j)=2;    
            end
        else
            filename = strcat(strcat(keyf1{i}, keyxy{j}),'.mat');  
            save(filename, 'symFfxy');
        end
        if mark(i,j)==0
            if ~exist('DerivativesFile')
            mkdir('DerivativesFile');
            addpath('DerivativesFile') ;
            end
            movefile(filename,'DerivativesFile');
        end
        end
    end     
end
fprintf('Checking procedure cost %2.4f seconds \n', toc(clock) );
addpath(genpath(pwd));
end

%--------------------------------------------------------------------------
function Diff= Diff1st2nd(Func, dim, key)
%%%% calculate the first order and second order derivatives

if isempty(Func)    
    Diff=[];    
else   
    n      =  dim(1);
    m      =  dim(2);
    x      =  sym('x',[n 1]); 
    y      =  sym('y',[m 1]); 
    
    switch key
        
    case {'x','y'} 
        switch    key 
        case 'x'; var = x;
        case 'y'; var = y;
        end       
        Jac    = jacobian(Func(x,y), var);  
        if  size(Func(rand(n,1),rand(m,1)),1)==1 && size(Jac,1)~=length(var) 
        Jac    = Jac'; 
        end 
        Diff   = Jac;
    case {'xx','xy', 'yx' 'yy'}                     
        switch  key 
            case 'xx'; row=n; col=n; var1= x; var2= x;
            case 'xy'; row=m; col=n; var1= x; var2= y;
            case 'yx'; row=n; col=m; var1= y; var2= x;   
            case 'yy'; row=m; col=m; var1= y; var2= y;
        end
        noF     = size(Func(rand(n,1),rand(m,1)),1);        
        Jac     = jacobian(Func(x,y), var2);                   
        Diff    = sym('hess',[noF*row col]); 
        for i   = 1:noF
        Hi      = @(x,y)Jac(i,:) ;
        Diff(1+row*(i-1):i*row,:) = jacobian(Hi(x,y),var1);  
        end 
    end
    
end
end

%-----------------------------------------------------------------------
function  Diff = Diff3rd(HessFunc, dim, keyxy)
% calculate 3rd order derevatives of Func
% Input:
%        HessFunc: the hessian matrix of Func. It is a symbolic function handle 
%                  R^{n x m} --> R^{q*row, col} with q>=1 
%        dim:      [n m], the dimensions of variable x \in  R^n and y\in R^m
%        keyxy:    derivative w.r.t. keyxy, 
%                  keyxy \in {'xxx','xxy','xyx', 'xyy','yxx','yxy','yyx','yyy'}
%
% Output: 
%        Diff:     derivative of Func w.r.t. keyxy, a symbolic handle


if ~isempty(HessFunc)
    nx      = dim(1);
    ny      = dim(2);
    x       = sym('x',[nx 1]);
    y       = sym('y',[ny 1]);    

    nvar    = size(HessFunc,1);
 
    if isequal(keyxy(1),'x')
        noF = nvar/nx; 
    else
        noF = nvar/ny; 
    end
 
    if isequal(keyxy(1),'x'); n1  = nx; else; n1  = ny; end
    if isequal(keyxy(3),'x'); n3  = nx; else; n3  = ny; end
    
    if isequal(keyxy(2),'x') 
        var =x; n2=nx; 
    else
        var =y; n2=ny; 
    end 
         
    if noF==1 
        Diff   =  sym('hess',[n1*n3  n2]); 
        for i  = 1: n1
            Hi = @(x,y)HessFunc(i,:); 
            Diff(1+n3*(i-1):n3*i,:) = jacobian(Hi(x,y),var);    
        end  
    else                                                             
        Diff    =  sym('hess',[noF*n3 n1*n2]);     
        for     i  = 1: noF
            for j  = 1: n1
                k  = j + n1*(i-1);
                Hi = @(x,y)HessFunc(k,:);  
                Ti = 1+n3*(i-1):n3*i;
                Tj = 1+n2*(j-1):n2*j;
                Diff(Ti,Tj) = jacobian(Hi(x,y),var);    
            end    
        end  
    end 
    
    if isequal(Diff,sym(zeros(size(Diff))))
       Diff =  [];
    end
     
else 
    Diff   =  [];
end

end

