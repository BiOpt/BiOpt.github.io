clc; clear; close all; 

ExNo      = 1;
switch ExNo
    case 1
    % this is a nonlinear bilevel optimsation prblem
    ExName = 'Colson2002BIPA1'; 
    dim    = [1 1 3 3];
    case 2
    % this is a simple bilevel optimsation prblem
    ExName = 'FrankeEtal2018Ex53'; 
    dim    = [1 2 4 4];
end

pars.draw  = 1;
pars.lam   = 1; 
pars.check = 1; 
func       = str2func(ExName);

% the first way to call a solver  
SolNo      = 3;     % choose the solver 
Solvers    = {'SNLLVF','SNQVI','SNKKT'};                                         
solver     = str2func(Solvers{SolNo});  
Out1       = solver(func, dim,  pars);

% the second way to call a solver 
% pars.check = 0;
% Out2       = SNLLVF(func, dim,  pars);