clc; clear; close all; 

ExName     = 'DempeDutta2012Ex24_ver1'; 
func       = str2func(ExName);
dim        = [1 1 0 1];
pars.xy    = [1;1];

pars.lam   = 1;
pars.keep  = 0; 
pars.check = 1; 

% the first way to call a solver  
SolNo      = 3;     % choose the solver
Solvers    = {'SNLLVF','SNQVI','SNKKT'}; 
solver     = str2func(Solvers{SolNo});  
Out1       = solver(func, dim,  pars);

% the second way to call a solver  
% Out2      = SNLLVF(func, dim,  pars);