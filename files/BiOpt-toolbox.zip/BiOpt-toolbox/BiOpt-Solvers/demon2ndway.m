clc; clear; close all; 

ExName     = 'DempeDutta2012Ex24_ver2'; 
func       = str2func(ExName);
dim        = [1 1 0 1];

pars.check = 0; 
Out1       = SNLLVF(func, dim,  pars);

pars.check = 1; 
pars.keep  = 0; 
Out2       = SNQVI(func, dim,  pars);

 