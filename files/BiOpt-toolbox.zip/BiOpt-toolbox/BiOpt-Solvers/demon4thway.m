clc; clear; close all; 

ExName     = 'LuDebSinha2016b_ver4'; 
func       = str2func(ExName);
dim        = [1 1 4 0];

pars.xy    = [1;1];
pars.lam   = 1; 
pars.check = 1; 

SolNo      = 1;    % choose the solver
Solvers    = {'SNLLVF','SNQVI','SNKKT'}; 
solver     = str2func(Solvers{SolNo});  
Out        = solver(func, dim,  pars);

 