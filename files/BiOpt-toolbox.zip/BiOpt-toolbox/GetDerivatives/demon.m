clc;  clear; close all;

Func   = @(x,y)([sin(x)+sum(y.^3); y.^norm(x,1)]); %
dim    = [2 3];
keyxy  = 'xyy';
DFunc  = GetDerivatives(Func, dim, keyxy);
Dkeyxy = DFunc(ones(dim(1),1),ones(dim(2),1)) 
%rmdir('DerivativesFolder','s');
       