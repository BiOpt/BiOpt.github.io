function [DFunc, symDFunc]  = GetDerivatives(Func, dim, keyxy)
% calculate 1st, 2nd or 3rd order derevatives of Func w.r.t. keyxy
% Input:
%        Func:    the input function handle, R^{nx x ny} --> R^{nf} with nf>=1 
%        dim:     [nx ny], the dimensions of variables x \in R^nx and y\in R^ny
%        keyxy:   derivative w.r.t. keyxy, 
%                 keyxy \in {'x','y','xx','xy','yx','yy' ,
%                            'xxx','xxy','xyx','xyy','yxx','yxy','yyx','yyy'}
%
% Output: 
%        DFunc:    derivative of Func w.r.t. keyxy, a fucntion handle
%        symDFunc: derivative of Func w.r.t. keyxy, a symbolic handle
%        Dimensions {row}x{col} of Diff and symDiff should be as follows:
%
%        keyxy               nf = 1                       nf > 1
%        ----------------------------------------------------------------- 
%        'x'         row = nx,    col = 1        row = nf,     col = nx
%        'y'         row = ny,    col = 1        row = nf,     col = ny 
%        'xx'        row = nx,    col = nx       row = nf*nx,  col = nx
%        'xy'        row = ny,    col = nx       row = nf*ny,  col = nx
%        'yx'        row = nx,    col = ny       row = nf*nx,  col = ny
%        'yy'        row = ny,    col = ny       row = nf*ny,  col = ny
%        'xxx'       row = nx*nx, col = nx       row = nf*nx,  col = nx*nx
%        'xxy'       row = nx*ny, col = nx       row = nf*ny,  col = nx*nx
%        'xyx'       row = nx*nx, col = ny       row = nf*nx,  col = nx*ny
%        'xyy'       row = nx*ny, col = ny       row = nf*ny,  col = nx*ny
%        'yxx'       row = ny*nx, col = nx       row = nf*nx,  col = ny*nx
%        'yxy'       row = ny*ny, col = nx       row = nf*ny,  col = ny*nx
%        'yyx'       row = ny*nx, col = ny       row = nf*nx,  col = ny*ny
%        'yyy'       row = ny*ny, col = ny       row = nf*ny,  col = ny*ny
%        -----------------------------------------------------------------
%
%   The basic rule for dimensions {a} x {b} of Diff and symDiff:
%   DFunc = D_{abc}Func where a, b, c \in {'x', 'y'}, let na, nb and nc
%   be dimensions of a, b and c, respectively. e.g. abc=xyx, then na=nx,
%   nb=ny and nc=nx.  D_{abc}Func has dimension {na*nc}x{nb}  if nf = 1
%                                              {q*nc}x{na*nb} if nf > 1
 

    
if  isempty(Func)  
    symDFunc = sym([]);
    DFunc    = @(xv,yv)[];
else
    nx      = dim(1);        
    ny      = dim(2);        
    x       = sym('x',[nx 1]);      
    y       = sym('y',[ny 1]);  
    
    if length(keyxy)<3             % calculate 1st or 2nd order derevatives
        [DFunc, symDFunc]= Diff1st2nd(Func, dim, keyxy);
    else                                  % calculate 3rd order derevatives
        key          = strcat(keyxy(3),keyxy(1));  
        [~, symDFunc] = Diff1st2nd(Func, dim, key); 
        X            = has(symDFunc,x);  
        Y            = has(symDFunc,y);
        if (max(X(:))==1 || max(Y(:))==1)
           [DFunc, symDFunc] = Diff3rd(symDFunc, dim,  keyxy);
        else
           symDFunc = sym([]);
           DFunc    = @(xv,yv)[];
        end
    end
    filename = strcat('D_', keyxy,'_fun.m');
    matlabFunction(symDFunc,'vars', {x, y}, 'file', filename); 
    
    if ~exist(  'DerivativesFolder')
        mkdir(  'DerivativesFolder'); 
        addpath('DerivativesFolder');
    end
    movefile(filename,'DerivativesFolder');        
end

end

%-------------------------------------------------------------------------
function [Diff, symDiff]= Diff1st2nd(Func, dim, key)
% calculate 1st or 2nd order derevatives of Func
% Input:
%        Func:   R^{nx x ny} --> R^nf with nf>=1, a function handle 
%        dim:    [nx ny], the dimensions of variable x \in R^nx and y\in R^ny
%        key:    derivative w.r.t. key, 
%                key \in {'x','y','xx','xy', 'yx', 'yy'}
%
% Output: 
%        Diff:    derivative of Func w.r.t. key, a fucntion handle
%        symDiff: derivative of Func w.r.t. key, a symbolic fucntion handle

    nx     =  dim(1);
    ny     =  dim(2);
    x      =  sym('x',[nx 1]); 
    y      =  sym('y',[ny 1]); 
   
    switch key
        case {'x','y'} 
            switch    key 
            case 'x'; var = x;
            case 'y'; var = y;
            end       
            Jac    = jacobian(Func(x,y), var);  
            noF    = size(Func(rand(nx,1),rand(ny,1)),1);
            if  noF==1 && size(Jac,1)~=length(var) 
            Jac    = Jac'; 
            end 
            symDiff= Jac;
            Diff   = @(xv,yv)double(subs(Jac, [x;y],  [xv;yv] ));
        
        case {'xx', 'xy', 'yx', 'yy'}                
            switch  key 
            case 'xx'; row=nx; col=nx; var1= x; var2= x;
            case 'xy'; row=ny; col=nx; var1= x; var2= y;
            case 'yx'; row=nx; col=ny; var1= y; var2= x;
            case 'yy'; row=ny; col=ny; var1= y; var2= y;
            end       
            noF     = size(Func(rand(nx,1),rand(ny,1)),1);        
            Jac     = jacobian(Func(x,y), var2); 
            symDiff = sym('hess',[noF*row col]); 
            for i   = 1:noF
            Hi      = @(x,y)Jac(i,:); 
            symDiff(1+row*(i-1):i*row,:) = jacobian(Hi(x,y),var1);
            end
        
            Diff = @(xv,yv)double(subs(symDiff, [x;y],  [xv;yv] ));        
    end
end


%-----------------------------------------------------------------------
function [Diff, symDiff] = Diff3rd(HessFunc, dim, keyxy)
% calculate 3rd order derevatives of Func
% Input:
%        HessFunc: the hessian matrix of Func. It is a symbolic function handle 
%                  R^{nx x ny} --> R^{nf*row, col} with nf>=1 
%        dim:      [nx ny], the dimensions of variable x \in R^nx and y\in R^ny
%        keyxy:    derivative w.r.t. keyxy, 
%                  keyxy \in {'xxx','xxy','xyx', 'xyy','yxx','yxy','yyx','yyy'}
%
% Output: 
%        Diff:    derivative of Func w.r.t. keyxy, a fucntion handle
%        symDiff: derivative of Func w.r.t. keyxy, a symbolic handle


if ~isempty(HessFunc)
    nx      = dim(1);
    ny      = dim(2);
    x       = sym('x',[nx 1]);
    y       = sym('y',[ny 1]);    

    nvar    = size(HessFunc,1);
 
    if isequal(keyxy(1),'x')
        noF = nvar/nx; 
    else
        noF = nvar/ny; 
    end
 
    if isequal(keyxy(1),'x'); n1  = nx; else; n1  = ny; end
    if isequal(keyxy(3),'x'); n3  = nx; else; n3  = ny; end
    
    if isequal(keyxy(2),'x') 
        var =x; n2=nx; 
    else
        var =y; n2=ny; 
    end 
         
    if noF==1 
        symDiff   =  sym('hess',[n1*n3  n2]); 
        for i  = 1: n1
            Hi = @(x,y)HessFunc(i,:); 
            symDiff(1+n3*(i-1):n3*i,:) = jacobian(Hi(x,y),var);    
        end  
    else                                                             
        symDiff    =  sym('hess',[noF*n3 n1*n2]);     
        for     i  = 1: noF
            for j  = 1: n1
                k  = j + n1*(i-1);
                Hi = @(x,y)HessFunc(k,:);  
                Ti = 1+n3*(i-1):n3*i;
                Tj = 1+n2*(j-1):n2*j;
                symDiff(Ti,Tj) = jacobian(Hi(x,y),var);    
            end    
        end  
    end 
    
    if isequal(symDiff,sym(zeros(size(symDiff))))
       Diff = @(xv,yv)[];
    else 
       Diff = @(xv,yv)double(subs(symDiff, [x; y],  [xv; yv] )); 
    end
     
else
    symDiff= sym([]); 
    Diff   = @(xv,yv)[];
end

end

