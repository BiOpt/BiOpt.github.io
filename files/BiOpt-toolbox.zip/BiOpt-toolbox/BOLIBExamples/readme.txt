This BOLIBExamples folder at least contains 1 txt-file, 1 pdf-file, 1 folder and 3 m-files:

     [1] Folder 'Examples' contains
     
           1.1) Folder 'Linear' contains 24 linear bilevel optimization examples
           1.2) Folder 'Nonlinear' contains 138  nonlinear bilevel optimization examples
           1.3) Folder 'Simple' contains 11 simple bilevel optimization examples
           1.4) 'InfomAllExamp.m' records the infomation of all examples
     
     [2] BOLIB2019_test_examples_library_version2.pdf: provides 173 academic examples of bilevel optimization  

     [3] 'demon1.m': one way to demonstrate  how to call one example.

     [4] 'demon2.m: another way to demonstrate how to call one example.

     [5] 'startup.m': add the path.


How to use this library:

     Step 1: Open  and run 'startup.m' to add the path;

     Step 2: Open  and run 'demon1.m'  to see  how to call one example, or  open  and run 'demon1.m'  to see  how to call one example.