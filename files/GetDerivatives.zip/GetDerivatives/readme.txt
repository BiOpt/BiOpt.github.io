
This GetDerivatives folder at least contains 1 txt-file,  1 folder and 2 m-files:

         [1]  Folder DerivativesFolder contains all calculated derivatives files
     
         [2]  'GetDerivatives.m': the main fucntion.

         [3]  'demon.m':  demonstrate  how to calculate the derivatives of a function.

How to use this tool:  Open  and run 'demon.m'.